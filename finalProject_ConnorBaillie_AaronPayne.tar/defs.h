#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

#define MAX_STR         64
#define MAX_RUNS        50
#define BOREDOM_MAX     100
#define C_TRUE          1
#define C_FALSE         0
#define HUNTER_WAIT     5000
#define GHOST_WAIT      600
#define NUM_HUNTERS     4
#define FEAR_MAX        10
#define LOGGING         C_TRUE

//typedef enum EvidenceType EvidenceType;
typedef enum GhostClass GhostClass;

typedef enum EvidenceType { EMF, TEMPERATURE, FINGERPRINTS, SOUND, EV_COUNT, EV_UNKNOWN } EvidenceEnumType;
enum GhostClass { POLTERGEIST, BANSHEE, BULLIES, PHANTOM, GHOST_COUNT, GH_UNKNOWN };
enum LoggerDetails { LOG_FEAR, LOG_BORED, LOG_EVIDENCE, LOG_SUFFICIENT, LOG_INSUFFICIENT, LOG_UNKNOWN };

// Helper Utilies
int randInt(int,int);        // Pseudo-random number generator function
float randFloat(float, float);  // Pseudo-random float generator function
enum GhostClass randomGhost();  // Return a randomly selected a ghost type
void ghostToString(enum GhostClass, char*); // Convert a ghost type to a string, stored in output paremeter
void evidenceToString(enum EvidenceType, char*); // Convert an evidence type to a string, stored in output parameter

// Logging Utilities
void l_hunterInit(char* name, enum EvidenceType equipment);
void l_hunterMove(char* name, char* room);
void l_hunterReview(char* name, enum LoggerDetails reviewResult);
void l_hunterCollect(char* name, enum EvidenceType evidence, char* room);
void l_hunterExit(char* name, enum LoggerDetails reason);
void l_ghostInit(enum GhostClass type, char* room);
void l_ghostMove(char* room);
void l_ghostEvidence(enum EvidenceType evidence, char* room);
void l_ghostExit(enum LoggerDetails reason);





typedef struct RoomList RoomListType;

typedef struct Room RoomType;

typedef struct RoomNode RoomNodeType;

typedef struct EvidenceNode EvidenceNodeType;

typedef struct EvidenceList EvidenceListType;

typedef struct Hunter HunterType;

typedef struct Ghost GhostType;

typedef struct House HouseType;



struct RoomList {

    RoomNodeType *head;
    RoomNodeType *tail;


};

struct EvidenceList {

    EvidenceNodeType *head;
    EvidenceNodeType *tail;

    int size;

    sem_t mutex;

};
struct RoomNode{

    RoomType *data;
    RoomNodeType *next;

};
struct EvidenceNode{

    EvidenceEnumType data;
    EvidenceNodeType *next;

};


struct Room {

    char name[MAX_STR];

    struct RoomList connectedRooms;

    int connectedRoomsSize;

    struct EvidenceList roomEvidence;

    HunterType *hunters[NUM_HUNTERS];

    int hunterCount;

    GhostType *ghost;

    sem_t mutex;
};

struct House {

    HunterType *allHunters[NUM_HUNTERS];

    GhostType *ghost;

    struct RoomList rooms;

    struct EvidenceList collectedEvidence;

};

struct Hunter{

    char name[MAX_STR];

    int fear;

    int boredom;

    RoomType *currRoom;

    EvidenceEnumType collectableEvidence;

    EvidenceListType *collectedEvidence;

};

struct Ghost{

    GhostClass ghostType;

    RoomType *currRoom;

    int boredom;


};



/* 
  Function: Initialize House Struct
  Purpose:  This function initializes a house struct. Will initialize the rooms list,
            hunters, and ghost.
  Params:  
    Input/Output: HouseType* - a pointer to the house struct that will be initialized. 
*/
void initHouse(HouseType*);

/* 
  Function: Initialize rooms list
  Purpose:  This function initializes a rooms list by setting it's head and tail pointers
            to NULL.
  Params:  
    Output: RoomListType* - A pointer to a RoomListType structure
*/
void initRoomsList(RoomListType*);


/* 
  Function: Initialize Evidence list
  Purpose:  This function initializes an EvidenceListType struct's head and tail pointers to NULL
  Params:  
    Output: EvidenceListType* - a pointer to the EvidenceListType struct that will be initialized. 
*/
void initEvidenceList(EvidenceListType*);


/* 
  Function: Create room struct
  Purpose:  This function creates a new room structure with the name passed into the function.
            This function is essentially initializing a room struct but returning a pointer to that struct.
  Params:  
    Input: char[] - The name of the room

  Return: After initializing a room struct a pointer to the room is returned
*/
RoomType* createRoom(char[]);


/* 
  Function: Connect Rooms
  Purpose:  This function will connect two rooms together. This is done by adding each room to each others connected room list.
            The connected rooms list of each room contains a list of pointers to room that are connected to each other
  Params:  
    Input/Output: RoomType* - Both RoomType*, pointers to rooms, are read and modified. They will be connected to each other
                            by adding each to each others list of connected rooms. 
*/
void connectRooms(RoomType*, RoomType*);


/* 
  Function: Initialize Room List Node
  Purpose:  This function initializes a node to be used in a room list
  Params:  
    Output: RoomNodeType **node - A double pointer to a room node. The node's data
                                member will point to the room data passed in, and it's next member will be set to NULL.
    Input:  RoomType *data - A pointer to a RoomType. This will be the data of a room node.
*/
void initRLNode(RoomNodeType **node, RoomType *data);

/* 
  Function: Add Room
  Purpose:  This function adds a RoomType to a roomlist. Makes use of helper functions in order
            to create a new room node with *room as the data. Adds this node to the end of the roomList
            linked list. If roomList is empty, the node is added as the head and tail.
  Params:  
    Input/Output:  RoomListType *roomList - the roomList that will be modified
    Input:         RoomType *room - the room that will be added to the roomList
*/
void addRoom(RoomListType *roomList, RoomType *room);

/* 
  Function: Populate rooms
  Purpose:  This function calls create room, for each room in the house, and calls connect
            room for every pair of rooms that must be connected. It also calls add room which 
            adds each room to the roomlist stored by house.
  Params:  
    Output: HouseType *house - a pointer to the house struct that the created rooms will be a part of. 
*/
void populateRooms(HouseType *house);

/* 
  Function: Populate Hunters
  Purpose: Asks the user for input for 4 names for hunters and passes that name to 
          a helper function which will initialize a hunter and return a pointer to 
          that hunter structure 
  Params:  
    Output: HouseType *house - a pointer to the house struct that the hunters will be a part of. 
*/
void populateHunters(HouseType *house);

/* 
  Function: Move Hunter
  Purpose:  Removes a hunter from its current room and moves the hunter to the specified room, which is connected to the 
            hunter's current room.
  Params:  
    Input/Output: RoomType *room - a pointer to a room structure which is the room that the hunter is going
                                  to move to.
    Input/Output: HunterType *hunter - a pointer to the hunter that gets moved   
*/
void moveHunter(RoomType *room, HunterType *hunter);

/* 
  Function: Initialize Ghost
  Purpose:  Initializes the ghost. The ghost is added to a random room in the house which cannot be the van.
  Params:  
    Output: HouseType *house - a pointer to the house struct that the ghost is in.
*/
void initGhost(HouseType *house);

/* 
  Function: Move Ghost
  Purpose:  Moves the ghost to a random connected room from the room that the ghost is currently in.
            The ghost will not move into a room where there is already a hunter
  Params:  
    Output: RoomType *room - a pointer to the room that the ghost is moving to.
    Output: GhostType *ghost - a pointer to the ghost that is being moved
*/
void moveGhost(RoomType *room, GhostType *ghost);

/* 
  Function: Initialize Evidence Node
  Purpose:  Initializes an evidence node to be used in an evidence list. The node is initialized
            with an evidence type as data and its next pointer pointing to NULL.
  Params:  
    Output: EvidenceNodeType **node - a double pointer to the node that is getting initialized
    Input:  EvidenceEnumType data - an evidence type that will be the data of the node
*/
void initEvNode(EvidenceNodeType **node, EvidenceEnumType data);

/* 
  Function: Drop Evidence
  Purpose:  Drops a random evidence type according to the three evidence types that the given ghost supports
  Params:  
    Input: GhostType *ghost - a pointer to a ghost which will drop evidence in its current room
  Return: Returns the evidence type that was dropped by the ghost

*/
EvidenceEnumType dropEvidence(GhostType *ghost);

/* 
  Function: Add to room Evidence list
  Purpose:  Handles adding an evidence node to a rooms evidence list.
  Params:  
    Input: EvidenceEnumType ev - the evidence type that is being added to the room's evidence list
    Input/Output: RoomType *room - the room that the evidence is being dropped in
*/
void addToRoomEvidenceList(EvidenceEnumType ev, RoomType *room);

/* 
  Function: Collect Evidence
  Purpose:  Collects a piece of evidence from the room the hunter is in.
  Params:  
    Input/Output: RoomType *room - a pointer to the room that the evidnece will be collected from.
    Input: HunterType *hunter - a pointer to the hunter that is collecting the evidence
*/
int collectEvidence(RoomType *room, HunterType *hunter);

/* 
  Function: Add to house evidence list
  Purpose:  Adds a collected piece of evidence to the shared evidence list in house.
  Params:  
    Input: EvidenceEnumType ev - the evidence type of the evidence that is being added
    Output: HunterType *hunter - the hunter that collected the evidence 
*/
void addToHouseEvidenceList(EvidenceEnumType ev, HunterType *hunter);

/* 
  Function: Get a connected room
  Purpose:  This function returns a pointer to a room that connected to the room passed into the function.
            The connected room that is returned is randomly chosen
  Params:  
    Input: RoomType *room - a pointer to the room that the hunter is moving from. The choices of connected rooms
                          are rooms that are connected with this room.
  Return: a pointer to the connected room that the hunter will move into.  
*/
RoomType* getConnectedRooms(RoomType *room);

/* 
  Function: Review Evidence
  Purpose:  Reviews the evidence that has been collected to see if the hunters have collected enough
            evidence to identify the ghost.
  Params:  
    Input:  EvidenceListType *collectedEv - a pointer to the list of evidence that has been collected

  Return:   an integer that represents the number of unique evidence types that have been collected. If this 
            number is 3 or more then the hunters have enough evidence to identify the ghost.
*/
int reviewEvidence(EvidenceListType *collectedEv);

/* 
  Function: Hunter Control Flow 
  Purpose:  Runs the main control flow for a hunter thread.
  Params:  
    Input/Output: void* arg -  a void pointer that is cast to a HunterType. This parameter is a pointer
    to a HunterType that the current control flow will handle. 
*/
void* hunterControlFLow(void*);

/* 
  Function: Ghost Control Flow 
  Purpose:  Runs the main control flow for a ghost thread.
  Params:  
    Input/Output: void* arg -  a void pointer that is cast to a HGhostType. This parameter is a pointer
    to a GhostType that the current control flow will handle. 
*/
void* ghostControlFlow(void*);

/* 
  Function: Remove Hunter from Room
  Purpose:  Removes a hunter from a room before the hunter is moved to another room.
  Params:  
    Input/Output: HunterType *hunter - a pointer to the hunter that is being removed from a room 
*/
void removeHunterFromRoom(HunterType *hunter);

/* 
  Function: Free Connected Rooms
  Purpose:  Deallocates the dynamic memory associated with room nodes in a connected rooms list.
            Does not deallocate any actual data, just the nodes, in order to prevent any double frees.
  Params:  
    Output: RoomType *room -  a pointer to the room that is having its connected rooms list deallocated. 
*/
void freeConnectedRooms(RoomType *room);

/* 
  Function: Free Evidence List 
  Purpose:  Deallocates the memory used for a linked list of evidence. This involves 
            deallocating the memory for each node in the list.
  Params:  
    Output: EvidenceListType -  a pointer to the head of a linked list of evidence that will be freed. 
*/
void freeEvidenceList(EvidenceListType *evList);

/* 
  Function: Free House 
  Purpose:  Deallocates all dynamically allocated memory associated with the game. Calls helper functions
            which free each dynamic member of the house struct.
  Params:  
    Output: HouseType *house -  a pointer to a HouseType struct that will have its dynamic memory deallocated 
*/
void freeHouse(HouseType *house);

/* 
  Function: Free Room List Data 
  Purpose: Frees the data associated with each individual room in a room list. Does not free the actual room list
          in order to prevent double frees.
  Params:  
    Output: RoomListType *list - a pointer to the head of a room list 
*/
void freeRoomListData(RoomListType *list);

/* 
  Function: Free Room List 
  Purpose:  Deallocates the dynamic memory for a room list along with the the actual room itself.
            This function is used after the data for each room has already been deallocated
  Params:  
    Output: RoomListType *list - a pointer to the head of a room list 
*/
void freeRoomList(RoomListType *list);

/* 
  Function: Free Hunters
  Purpose:  Deallocates the dynamic memory associated with each hunter that was initialized
  Params:  
    Output: HouseType *house - a pointer to a HouseType which contains a list of all hunters.
            The list will be iterated and each hunter will be freed. 
*/
void freeHunters(HouseType *house);

/* 
  Function: End of Game Print 
  Purpose:  Prints an overview of the end result of the game after it has concluded
  Params:  
    Input: HouseType *house -  a pointer to a HouseType structure that will be read from in order to display
                              the results of the game. 
*/
void endGamePrint(HouseType *house);

/* 
  Function: Create Hunter  
  Purpose:  Initializes a HunterType and returns a pointer to the hunter struct.
  Params:  
    Input: char *name -  the name that the hunter will be initialized with.
    Input: int i - a number that is used to determine what type of evidence the hunter will be able to collect.
    HouseType *house - a pointer to a HouseType where this hunter is located.
  Return: A pointer to a HunterType struct.
*/
HunterType* createHunter(char *name, int i, HouseType *house);


