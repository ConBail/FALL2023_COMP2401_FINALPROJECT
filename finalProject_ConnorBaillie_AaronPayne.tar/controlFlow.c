#include "defs.h"

void* hunterControlFLow(void* arg){
    HunterType *hunter = (HunterType*) arg;
    while (C_TRUE)
    {
        if(hunter->boredom == BOREDOM_MAX){
           
            l_hunterExit(hunter->name, LOG_BORED);

            
            

            removeHunterFromRoom(hunter);
            


            return NULL;
            
        }
        if(hunter->fear == FEAR_MAX){
            
            l_hunterExit(hunter->name, LOG_FEAR);

            removeHunterFromRoom(hunter);
            



            return NULL;
        }
        
        if(hunter->currRoom->ghost != NULL){
            hunter->fear++;
            hunter->boredom = 0;
        }
        else{
            hunter->boredom++;
        }
        int whichAction = randInt(0,3);
        if(whichAction == 0){
            
            moveHunter(getConnectedRooms(hunter->currRoom), hunter);
            
            l_hunterMove(hunter->name, hunter->currRoom->name);
        }
        if(whichAction == 1){
            
            if(C_TRUE == collectEvidence(hunter->currRoom, hunter)){
                l_hunterCollect(hunter->name, hunter->collectableEvidence, hunter->currRoom->name);
            }
        }
        if(whichAction == 2){
            
            if(C_TRUE == reviewEvidence(hunter->collectedEvidence)){
                
                l_hunterReview(hunter->name, LOG_SUFFICIENT);
                l_hunterExit(hunter->name, LOG_EVIDENCE);

                removeHunterFromRoom(hunter);
                


                return NULL;
            }
            else{
                l_hunterReview(hunter->name, LOG_INSUFFICIENT);
            }
        }
        usleep(HUNTER_WAIT);
    }
    

}

void* ghostControlFlow(void* arg){
    GhostType *ghost = (GhostType*) arg;
    int whichAction;
    while(C_TRUE){
        
        if(ghost->boredom == BOREDOM_MAX){
            
            l_ghostExit(LOG_BORED);
            ghost->currRoom->ghost = NULL;
            return NULL;
        }
        if(ghost->currRoom->hunterCount != 0){
            ghost->boredom =0;
            whichAction = randInt(1,3);
        }
        else{
            ghost->boredom++;
            whichAction = randInt(0,3);
        }

        
        if(whichAction == 0){
            RoomType *ghostToRoom = getConnectedRooms(ghost->currRoom);
            
            
            moveGhost(ghostToRoom,ghost);
                
            l_ghostMove(ghost->currRoom->name);
            
            
        }
        if(whichAction == 1){
            printf("dropping evidence");
           l_ghostEvidence(dropEvidence(ghost), ghost->currRoom->name);

        }
        if(whichAction ==2){
            continue;
        }
        usleep(GH_UNKNOWN);
    }
}