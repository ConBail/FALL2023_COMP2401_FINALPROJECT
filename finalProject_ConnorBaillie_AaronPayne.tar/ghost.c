#include "defs.h"



void initGhost(HouseType *house){


    GhostType *newGhost = malloc(sizeof(GhostType));
    



    newGhost->boredom = 0;

    newGhost->ghostType = randomGhost();
    

    int roomChoice = randInt(1, 13);
    

    house->ghost = newGhost;
    

    RoomNodeType *currRoom = house->rooms.head;
    

    for (int i = 0; i < roomChoice; i++)
    {
        currRoom = currRoom->next;
        
    }
    
    newGhost->currRoom = currRoom->data;
    

    currRoom->data->ghost = newGhost;
    

    l_ghostInit(newGhost->ghostType, newGhost->currRoom->name);
}

void moveGhost(RoomType *room, GhostType *ghost){

    ghost->currRoom->ghost = NULL;

    ghost->currRoom = room;

    room->ghost = ghost;




}