#include "defs.h"

int main()
{
    // Initialize the random number generator
    srand(time(NULL));

    HouseType house;
    initHouse(&house);
    
    pthread_t hunter1, hunter2, hunter3, hunter4, ghost;

    pthread_create(&ghost, NULL, ghostControlFlow, house.ghost);
    pthread_create(&hunter1, NULL, hunterControlFLow, house.allHunters[0]);
    pthread_create(&hunter2, NULL, hunterControlFLow, house.allHunters[1]);
    pthread_create(&hunter3, NULL, hunterControlFLow, house.allHunters[2]);
    pthread_create(&hunter4, NULL, hunterControlFLow, house.allHunters[3]);

    pthread_join(ghost,NULL);
    pthread_join(hunter1,NULL);
    pthread_join(hunter2,NULL);
    pthread_join(hunter3,NULL);
    pthread_join(hunter4,NULL);

    
    endGamePrint(&house);
    freeHouse(&house);
    

    return 0;
}